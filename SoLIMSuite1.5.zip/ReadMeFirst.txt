This release contains SoLIM Suite 1.5. After unpacking, you should have
the following files:

TestGISDATA - a directory contains the tutorial data
SoLIMSuite.exx - the SoLIM Suite 1.5 program (needs to be renamed to SoLIMSuite.exe)
SoLIMSuite.cnt - the content of the Win help file
SoLIMSuite.hlp - the win help file
ReadMeFirst.txt - this file

Some of the virus detection programs does not allow
zip file which contains any .exe files to be downloaded.
The SoLIM Suite Program has been renamed to SoLIMSuite.exx
for distribution. You need to rename SoLIMSuite.exx to 
SoLIMSuite.exe before using SoLIM.

New Features over SoLIM Suite 1.0:

1) It does not require the spatial extents of all GIS data layers 
   used in the inference to be exactly the same. However, the 
   spatial extent of the outputs will be the same as that of the 
   first data layer in the data layer list.

2) It can now import knowledge curves which were created by other programs
   such as data mining programs. (See the help file for more details).