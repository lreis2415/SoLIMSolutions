Currently the data mining tool set contains two 
programs: the KnowledgeMiner and the KnowledgeComparator.

Both programs currently have the .exx extension and need to
be renamed to .exe before they can be run.